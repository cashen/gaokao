const fs=require('fs');
const path=require('path');
const root=process.cwd();
function read(p){return fs.readFileSync(path.join(root,p),'utf8');}
function exists(p){return fs.existsSync(path.join(root,p));}
function assert(ok,msg){if(!ok){console.error('FAIL:',msg);process.exitCode=1;}}
const index=read('fenxi/index.html');
const debug=read('fenxi/debug.html');
const app=read('fenxi/assets/app.v2983.js');
const compute=read('fenxi/assets/compute-pipeline.v2983.js');
const runtime=read('fenxi/assets/debug-runtime.v2983.js');
const self=read('fenxi/assets/debug-selftest.v2983fix10.js');
const version=read('fenxi/VERSION.txt');
assert(exists('fenxi/assets/debug-selftest.v2983fix10.js'),'debug selftest script exists');
assert(index.includes('V2.9.8.3.fix10'),'index version fix10');
assert(index.includes('2983fix10-20260511'),'index stamp fix10');
assert(debug.includes('V2.9.8.3.fix10'),'debug title fix10');
assert(debug.includes('debug-selftest.v2983fix10.js'),'debug loads selftest');
assert(app.includes('v2983fix10'),'body class contains v2983fix10');
assert(app.includes('Debug一键联动自测与矩阵体检版'),'app title updated');
assert(compute.includes("computePipeline:'v2983fix10'"),'compute pipeline flag fix10');
assert(compute.includes("version:'V2.9.8.3.fix10'"),'compute pipeline version fix10');
assert(runtime.includes('V2.9.8.3.fix10'),'debug runtime default version fix10');
assert(self.includes('runSmokeSelfTest'),'selftest quick button binding');
assert(self.includes('runDeepSelfTest'),'selftest deep button binding');
assert(self.includes('ln_v2983_selftest_report'),'selftest report key');
assert(self.includes('manualOnly-fast-interest'),'manualOnly fast interest test present');
assert(self.includes('sampleUnexpectedKept'),'region hard assertion present');
assert(self.includes('maxCases=96'),'deep matrix safety cap present');
assert(version.includes('V2.9.8.3.fix10'),'VERSION fix10');
assert(exists('docs/V2.9.8.3.fix10_Debug一键联动自测与矩阵体检版说明.md'),'root docs fix10 exists');
assert(exists('fenxi/docs/V2.9.8.3.fix10_Debug一键联动自测与矩阵体检版说明.md'),'fenxi docs fix10 exists');
const topItems=fs.readdirSync(root).filter(x=>!['fenxi','functions','docs','tools'].includes(x));
assert(topItems.length===0,'fenxi-only update: no root extra items: '+topItems.join(','));
if(process.exitCode){process.exit(process.exitCode);}else{console.log('All V2.9.8.3.fix10 checks passed.');}
